const express = require('express');
const multer = require('multer');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');

const app = express();
const port = 3060;

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));

// Multer setup
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const folder = determineFolder(file.mimetype);
        cb(null, `public/${folder}`);
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = crypto.randomBytes(4).toString('hex');
        cb(null, uniqueSuffix + '-' + file.originalname);
    }
});

const upload = multer({ storage });

// Determine folder based on file type
function determineFolder(mimeType) {
    if (mimeType.startsWith('image')) {
        return 'images';
    } else if (mimeType.startsWith('video')) {
        return 'videos';
    } else {
        return 'files';
    }
}

// Serve the HTML page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Handle file upload
app.post('/upload', upload.single('file'), (req, res) => {
    const token = crypto.randomBytes(16).toString('hex');
    const filePath = req.file.path;
    const originalName = req.file.originalname;

    const data = {
        token,
        filePath,
        originalName
    };
    fs.writeFileSync(`public/randoms/${token}.json`, JSON.stringify(data));

    res.redirect(`/?token=${token}`); // Corrected redirect URL
});


// Handle retrieving files using token
app.get('/retrieve', (req, res) => {
    const token = req.query.token;
    const filePath = `public/randoms/${token}.json`;

    if (fs.existsSync(filePath)) {
        const data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
        res.sendFile(path.join(__dirname, data.filePath));
    } else {
        res.send('File not found.');
    }
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});